// server.js
// OPEN WALLET - Secure Non-Custodial Backend
//
// IMPORTANT:
// - Private keys / seed phrases are NEVER generated, stored or received here.
// - Wallet generation and transaction signing must happen on the user's device.
// - This server stores public addresses and reads blockchain data.
// - /api/send/prepare only validates and prepares a transaction plan.
//   The frontend must build/sign/broadcast the actual transaction.

const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const mongoose = require("mongoose");
const crypto = require("crypto");
const { ethers } = require("ethers");
const TronWebModule = require("tronweb");
const { Connection, PublicKey } = require("@solana/web3.js");

const TronWeb = TronWebModule.TronWeb || TronWebModule;

const app = express();

/* =========================================================
   CONFIG
========================================================= */

const PORT = Number(process.env.PORT || 10000);

const MONGO_URI = (process.env.MONGO_URI || "").trim();
const BOT_TOKEN = (process.env.BOT_TOKEN || "").trim();
const TRONGRID_API_KEY = (process.env.TRONGRID_API_KEY || "").trim();

const PLATFORM_FEE_PERCENT = 0.5;
const SWIPE_SWAP_FEE_PERCENT = 0;
const MIN_TRANSACTION_USD = 0.10;
const MAX_TRANSACTION_USD = null; // Outgoing Send has no application maximum.

// A transaction is never credited/displayed as confirmed until the chain
// itself reports a successful transaction with enough confirmations.
const MIN_CONFIRMATIONS = {
  ETH: 12,
  OPTIMISM: 12,
  ARBITRUM: 12,
  BASE: 12,
  TRON: 20,
  SOLANA: 1,
  BITCOIN: 2
};

// CoinGecko prices are cached briefly to avoid unnecessary API calls.
const PRICE_CACHE_TTL_MS = 30 * 1000;
let priceCache = {
  fetchedAt: 0,
  prices: null
};

const EVM_NETWORKS = {
  ETH: {
    name: "Ethereum Mainnet",
    chainId: 1,
    rpc:
      process.env.ETH_RPC ||
      "https://ethereum-rpc.publicnode.com",
    usdt:
      process.env.ETH_USDT_CONTRACT ||
      "0xdAC17F958D2ee523a2206206994597C13D831ec7"
  },

  OPTIMISM: {
    name: "Optimism",
    chainId: 10,
    rpc:
      process.env.OPTIMISM_RPC ||
      "https://optimism-rpc.publicnode.com",
    usdt: process.env.OPTIMISM_USDT_CONTRACT || ""
  },

  ARBITRUM: {
    name: "Arbitrum One",
    chainId: 42161,
    rpc:
      process.env.ARBITRUM_RPC ||
      "https://arbitrum-one-rpc.publicnode.com",
    usdt:
      process.env.ARBITRUM_USDT_CONTRACT ||
      "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9"
  },

  BASE: {
    name: "Base",
    chainId: 8453,
    rpc:
      process.env.BASE_RPC ||
      "https://base-rpc.publicnode.com",
    usdt: process.env.BASE_USDT_CONTRACT || ""
  }
};

const TRON_USDT_CONTRACT =
  process.env.TRON_USDT_CONTRACT ||
  "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";

const SOLANA_RPC =
  process.env.SOLANA_RPC ||
  "https://api.mainnet-beta.solana.com";

// Official Tether USDt mint on Solana. Keep this hard-coded as an allow-list
// anchor; arbitrary tokens named "USDT" must never be accepted.
const SOLANA_USDT_MINT =
  process.env.SOLANA_USDT_MINT ||
  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB";

const BITCOIN_API =
  process.env.BITCOIN_API ||
  "https://blockstream.info/api";

/*
 * Put ONLY public receiving fee addresses here.
 * NEVER put private keys or seed phrases in environment variables.
 */
const FEE_ADDRESSES = {
  ETHEREUM: (process.env.FEE_ADDRESS_ETHEREUM || "").trim(),
  TRON: (process.env.FEE_ADDRESS_TRON || "").trim(),
  BITCOIN: (process.env.FEE_ADDRESS_BITCOIN || "").trim(),
  SOLANA: (process.env.FEE_ADDRESS_SOLANA || "").trim()
};

/* =========================================================
   MIDDLEWARE
========================================================= */

app.disable("x-powered-by");

app.use(
  express.json({
    limit: "20kb"
  })
);

app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"]
  })
);

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: "Too many requests. Please try again later."
  }
});

app.use("/api/", apiLimiter);

/* =========================================================
   TRON
========================================================= */

const tronHeaders = {};

if (TRONGRID_API_KEY) {
  tronHeaders["TRON-PRO-API-KEY"] = TRONGRID_API_KEY;
}

const tronWeb = new TronWeb({
  fullHost: "https://api.trongrid.io",
  headers: tronHeaders
});

/* =========================================================
   DATABASE
========================================================= */

const UserSchema = new mongoose.Schema(
  {
    telegramId: {
      type: String,
      required: true,
      unique: true,
      index: true
    },

    /*
     * Public wallet addresses only.
     * No privateKey, seedPhrase, mnemonic or secret is stored.
     */
    addresses: {
      tron: {
        type: String,
        default: ""
      },

      evm: {
        type: String,
        default: ""
      },

      solana: {
        type: String,
        default: ""
      },

      bitcoin: {
        type: String,
        default: ""
      }
    },

    createdAt: {
      type: Date,
      default: Date.now
    },

    updatedAt: {
      type: Date,
      default: Date.now
    }
  },
  {
    versionKey: false
  }
);

UserSchema.pre("save", function (next) {
  this.updatedAt = new Date();
  next();
});

const User = mongoose.model("User", UserSchema);

// This collection is an audit/verification ledger only. It is deliberately
// NOT a balance ledger. Wallet balances remain on-chain.
const TransactionVerificationSchema = new mongoose.Schema(
  {
    telegramId: { type: String, required: true, index: true },
    txHash: { type: String, required: true },
    chain: { type: String, required: true },
    asset: { type: String, required: true },
    direction: { type: String, enum: ["in", "out"], required: true },
    status: { type: String, enum: ["verified", "pending", "rejected"], required: true },
    confirmations: { type: Number, default: 0 },
    amount: { type: String, default: "0" },
    address: { type: String, default: "" },
    tokenContract: { type: String, default: "" },
    blockNumber: { type: Number, default: null },
    reason: { type: String, default: "" },
    senderAddress: { type: String, default: "" },
    recipientAddress: { type: String, default: "" },
    usdValue: { type: Number, default: 0 },
    platformFee: { type: String, default: "0" },
    feeRecipient: { type: String, default: "" },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
  },
  { versionKey: false }
);

TransactionVerificationSchema.index(
  { telegramId: 1, txHash: 1, chain: 1, direction: 1 },
  { unique: true }
);

const TransactionVerification =
  mongoose.model("TransactionVerification", TransactionVerificationSchema);

const SessionSchema = new mongoose.Schema({
  telegramId: { type:String, required:true, index:true },
  sessionIdHash: { type:String, required:true, unique:true, index:true },
  deviceLabel: { type:String, default:"Unknown device" },
  userAgent: { type:String, default:"" },
  ipHash: { type:String, default:"" },
  trusted: { type:Boolean, default:false },
  blocked: { type:Boolean, default:false },
  sensitiveVerifiedUntil: { type:Date, default:null },
  firstSeenAt: { type:Date, default:Date.now },
  lastSeenAt: { type:Date, default:Date.now }
},{versionKey:false});
const Session = mongoose.model("Session", SessionSchema);

/* =========================================================
   TELEGRAM AUTH
========================================================= */

function verifyTelegramWebAppData(initData) {
  if (!initData || !BOT_TOKEN) {
    return false;
  }

  try {
    const params = new URLSearchParams(initData);
    const receivedHash = params.get("hash");

    if (!receivedHash) {
      return false;
    }

    params.delete("hash");

    const dataCheckArr = [];

    for (const [key, value] of params.entries()) {
      dataCheckArr.push(`${key}=${value}`);
    }

    dataCheckArr.sort();

    const dataCheckString = dataCheckArr.join("\n");

    const secretKey = crypto
      .createHmac("sha256", "WebAppData")
      .update(BOT_TOKEN)
      .digest();

    const calculatedHash = crypto
      .createHmac("sha256", secretKey)
      .update(dataCheckString)
      .digest("hex");

    if (
      calculatedHash.length !== receivedHash.length ||
      !/^[a-f0-9]+$/i.test(receivedHash)
    ) {
      return false;
    }

    return crypto.timingSafeEqual(
      Buffer.from(calculatedHash, "utf8"),
      Buffer.from(receivedHash, "utf8")
    );
  } catch (error) {
    console.error(
      "Telegram verification error:",
      error.message
    );

    return false;
  }
}

function getTelegramUserId(initData) {
  try {
    const params = new URLSearchParams(initData);
    const userJson = params.get("user");

    if (!userJson) {
      return null;
    }

    const user = JSON.parse(userJson);

    if (!user.id) {
      return null;
    }

    return String(user.id);
  } catch {
    return null;
  }
}

function authenticateTelegramRequest(telegramId, initData) {
  if (!telegramId || !initData || !BOT_TOKEN) {
    return false;
  }

  if (!verifyTelegramWebAppData(initData)) {
    return false;
  }

  const verifiedId = getTelegramUserId(initData);

  return (
    verifiedId !== null &&
    verifiedId === String(telegramId)
  );
}

function hashValue(value) { return crypto.createHash("sha256").update(String(value || "")).digest("hex"); }
function getClientIp(req) { return String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").split(",")[0].trim(); }
function getDeviceLabel(req) {
  const ua=String(req.headers["user-agent"]||"");
  if(/Android/i.test(ua)) return "Android device";
  if(/iPhone|iPad|iPod/i.test(ua)) return "iOS device";
  if(/Windows/i.test(ua)) return "Windows device";
  if(/Mac OS X/i.test(ua)) return "macOS device";
  return "Web device";
}
async function getOrCreateSession({telegramId,sessionId,req}) {
  if(!sessionId || typeof sessionId!=="string" || sessionId.length<16 || sessionId.length>200) throw new Error("Secure device/session identifier is required");
  const hash=hashValue(sessionId); let session=await Session.findOne({sessionIdHash:hash}); const now=new Date();
  if(!session){
    const count=await Session.countDocuments({telegramId:String(telegramId)});
    session=await Session.create({telegramId:String(telegramId),sessionIdHash:hash,deviceLabel:getDeviceLabel(req),userAgent:String(req.headers["user-agent"]||"").slice(0,500),ipHash:hashValue(getClientIp(req)),trusted:count===0,sensitiveVerifiedUntil:count===0 ? new Date(Date.now()+15*60*1000) : null,lastSeenAt:now,firstSeenAt:now});
  } else {
    if(session.telegramId!==String(telegramId)) throw new Error("Session/account mismatch");
    if(session.blocked) throw new Error("This device/session is blocked");
    session.lastSeenAt=now; await session.save();
  }
  return session;
}
async function requireSecureSession({telegramId,initData,sessionId,req,sensitive=false}) {
  if(!authenticateTelegramRequest(telegramId,initData)) throw new Error("Unauthorized request");
  const session=await getOrCreateSession({telegramId,sessionId,req});
  if(sensitive && (!session.trusted || !session.sensitiveVerifiedUntil || session.sensitiveVerifiedUntil<new Date())) {
    const e=new Error("Additional device verification is required before Send/Swap"); e.code="DEVICE_VERIFICATION_REQUIRED"; throw e;
  }
  return session;
}

/* =========================================================
   VALIDATION
========================================================= */

function isValidEvmAddress(address) {
  try {
    return Boolean(address) && ethers.isAddress(address);
  } catch {
    return false;
  }
}

function isValidTronAddress(address) {
  try {
    return Boolean(address) && tronWeb.isAddress(address);
  } catch {
    return false;
  }
}

function isValidSolanaAddress(address) {
  try {
    new PublicKey(address);
    return true;
  } catch {
    return false;
  }
}

/*
 * Bitcoin validation is intentionally conservative.
 * The backend accepts common mainnet P2PKH, P2SH, Bech32 and Taproot
 * address formats. Full script validation should still happen in the
 * signing wallet.
 */
function isValidBitcoinAddress(address) {
  if (!address || typeof address !== "string") {
    return false;
  }

  const value = address.trim();

  return (
    /^(1|3)[a-km-zA-HJ-NP-Z1-9]{25,62}$/.test(value) ||
    /^bc1[ac-hj-np-z02-9]{11,87}$/.test(value)
  );
}

function isValidAmount(value) {
  const s = String(value ?? "").trim();

  if (!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(s)) {
    return false;
  }

  const n = Number(s);

  return Number.isFinite(n) && n > 0;
}

async function getUsdPrices() {
  const now = Date.now();

  if (
    priceCache.prices &&
    now - priceCache.fetchedAt < PRICE_CACHE_TTL_MS
  ) {
    return priceCache.prices;
  }

  const ids =
    "bitcoin,ethereum,tether,solana,tron";

  const response = await fetch(
    `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`
  );

  if (!response.ok) {
    throw new Error(
      `Price API HTTP ${response.status}`
    );
  }

  const data = await response.json();

  const prices = {
    BTC: Number(data.bitcoin?.usd || 0),
    ETH: Number(data.ethereum?.usd || 0),
    USDT: Number(data.tether?.usd || 0),
    SOL: Number(data.solana?.usd || 0),
    TRX: Number(data.tron?.usd || 0)
  };

  for (const [asset, price] of Object.entries(prices)) {
    if (!Number.isFinite(price) || price <= 0) {
      throw new Error(
        `Unable to get a valid USD price for ${asset}`
      );
    }
  }

  priceCache = {
    fetchedAt: now,
    prices
  };

  return prices;
}

async function getUsdValue(amount, asset) {
  const prices = await getUsdPrices();
  const normalizedAsset = String(asset || "").toUpperCase();
  const price = prices[normalizedAsset];

  if (!price) {
    throw new Error(
      `USD price is not available for ${normalizedAsset}`
    );
  }

  return {
    price,
    usdValue: Number(amount) * price
  };
}

function enforceUsdTransactionLimits(usdValue, direction) {
  const value = Number(usdValue);
  if (!Number.isFinite(value) || value <= 0) throw new Error("Invalid USD transaction value");
  if (value < MIN_TRANSACTION_USD) throw new Error(`Minimum ${direction} amount is $${MIN_TRANSACTION_USD.toFixed(2)} USD equivalent. Current value is approximately $${value.toFixed(4)}.`);
  // Incoming external deposits and outgoing Send have no application maximum.
  // Blockchain/network/provider limits may still apply outside this application.
  if (["receive", "send"].includes(String(direction).toLowerCase())) return;
  if (MAX_TRANSACTION_USD !== null && value > MAX_TRANSACTION_USD) throw new Error(`Maximum ${direction} amount is $${MAX_TRANSACTION_USD.toFixed(2)} USD equivalent. Current value is approximately $${value.toFixed(4)}.`);
}

function calculateFee(amount) {
  const gross = Number(amount);
  const fee = gross * (PLATFORM_FEE_PERCENT / 100);
  const receive = gross - fee;

  return {
    gross,
    fee,
    receive
  };
}

function getFeeAddress(chain, asset) {
  const c = String(chain || "").toUpperCase();
  const a = String(asset || "").toUpperCase();

  if (
    c === "TRON"
  ) {
    return FEE_ADDRESSES.TRON;
  }

  if (
    c === "SOLANA"
  ) {
    return FEE_ADDRESSES.SOLANA;
  }

  if (
    c === "BITCOIN"
  ) {
    return FEE_ADDRESSES.BITCOIN;
  }

  if (EVM_NETWORKS[c] && ["ETH", "USDT"].includes(a)) {
    return FEE_ADDRESSES.ETHEREUM;
  }

  return "";
}

/* =========================================================
   PROVIDERS
========================================================= */

function getEvmProvider(networkKey) {
  const key = String(networkKey || "").toUpperCase();
  const network = EVM_NETWORKS[key];

  if (!network) {
    throw new Error("Unsupported EVM network");
  }

  return new ethers.JsonRpcProvider(
    network.rpc,
    {
      name: network.name,
      chainId: network.chainId
    },
    {
      staticNetwork: true
    }
  );
}

function getSolanaConnection() {
  return new Connection(
    SOLANA_RPC,
    "confirmed"
  );
}

/* =========================================================
   BALANCES
========================================================= */

async function getTronBalances(address) {
  let trx = 0;
  let usdt = 0;

  if (!address) {
    return { trx, usdt };
  }

  try {
    const balance = await tronWeb.trx.getBalance(address);
    trx = Number(balance) / 1e6;
  } catch (error) {
    console.error(
      "TRX balance error:",
      error.message
    );
  }

  try {
    const contract =
      await tronWeb.contract().at(TRON_USDT_CONTRACT);

    const raw =
      await contract.balanceOf(address).call();

    usdt = Number(raw.toString()) / 1e6;
  } catch (error) {
    console.error(
      "TRC20 USDT balance error:",
      error.message
    );
  }

  return {
    trx,
    usdt
  };
}

async function getEvmNativeBalance(networkKey, address) {
  if (!address) {
    return 0;
  }

  const provider = getEvmProvider(networkKey);
  const balance = await provider.getBalance(address);

  return Number(
    ethers.formatEther(balance)
  );
}

async function getEvmUsdtBalance(networkKey, address) {
  if (!address) {
    return 0;
  }

  const network =
    EVM_NETWORKS[String(networkKey).toUpperCase()];

  if (!network || !network.usdt) {
    return 0;
  }

  const provider = getEvmProvider(networkKey);

  const abi = [
    "function balanceOf(address) view returns (uint256)",
    "function decimals() view returns (uint8)"
  ];

  const contract = new ethers.Contract(
    network.usdt,
    abi,
    provider
  );

  const [raw, decimals] = await Promise.all([
    contract.balanceOf(address),
    contract.decimals()
  ]);

  return Number(
    ethers.formatUnits(raw, decimals)
  );
}

async function getBitcoinBalance(address) {
  if (!address) {
    return 0;
  }

  try {
    const response = await fetch(
      `${BITCOIN_API}/address/${encodeURIComponent(address)}`
    );

    if (!response.ok) {
      throw new Error(
        `Bitcoin API HTTP ${response.status}`
      );
    }

    const data = await response.json();

    const funded =
      Number(data.chain_stats?.funded_txo_sum || 0);

    const spent =
      Number(data.chain_stats?.spent_txo_sum || 0);

    return (funded - spent) / 1e8;
  } catch (error) {
    console.error(
      "Bitcoin balance error:",
      error.message
    );

    return 0;
  }
}

/* =========================================================
   ON-CHAIN TRANSACTION VERIFICATION
========================================================= */

const ERC20_TRANSFER_IFACE = new ethers.Interface([
  "event Transfer(address indexed from, address indexed to, uint256 value)"
]);

function normalizeAddress(address) {
  return String(address || "").trim().toLowerCase();
}

function getUserAddressForChain(user, chain) {
  const c = String(chain || "").toUpperCase();

  if (["ETH", "OPTIMISM", "ARBITRUM", "BASE"].includes(c)) {
    return user.addresses.evm;
  }

  if (c === "TRON") return user.addresses.tron;
  if (c === "SOLANA") return user.addresses.solana;
  if (c === "BITCOIN") return user.addresses.bitcoin;

  return "";
}

function getRequiredConfirmations(chain) {
  return MIN_CONFIRMATIONS[String(chain || "").toUpperCase()] || 12;
}

async function verifyEvmUsdtContract(networkKey) {
  const network = EVM_NETWORKS[String(networkKey).toUpperCase()];

  if (!network || !network.usdt) {
    throw new Error(`USDT is not enabled on ${networkKey}`);
  }

  const provider = getEvmProvider(networkKey);
  const contract = new ethers.Contract(
    network.usdt,
    [
      "function symbol() view returns (string)",
      "function decimals() view returns (uint8)"
    ],
    provider
  );

  const [symbol, decimals] = await Promise.all([
    contract.symbol(),
    contract.decimals()
  ]);

  if (String(symbol).toUpperCase() !== "USDT" || Number(decimals) !== 6) {
    throw new Error("Configured USDT contract metadata verification failed");
  }

  return {
    address: network.usdt,
    decimals: Number(decimals)
  };
}

async function verifyEvmTransaction({
  networkKey,
  txHash,
  walletAddress,
  direction,
  expectedAmount,
  expectedRecipient
}) {
  const key = String(networkKey).toUpperCase();
  const network = EVM_NETWORKS[key];

  if (!network) throw new Error("Unsupported EVM network");
  if (!ethers.isHexString(txHash, 32)) throw new Error("Invalid EVM transaction hash");
  if (!isValidEvmAddress(walletAddress)) throw new Error("Invalid wallet address");

  const provider = getEvmProvider(key);
  const net = await provider.getNetwork();

  if (Number(net.chainId) !== network.chainId) {
    throw new Error("RPC chain ID verification failed");
  }

  const tx = await provider.getTransaction(txHash);
  if (!tx) throw new Error("Transaction not found on the configured blockchain");

  const receipt = await provider.getTransactionReceipt(txHash);
  if (!receipt) {
    return {
      status: "pending",
      confirmations: 0,
      amount: "0",
      blockNumber: null,
      reason: "Transaction is not mined yet"
    };
  }

  if (receipt.status !== 1) {
    return {
      status: "rejected",
      confirmations: 0,
      amount: "0",
      blockNumber: receipt.blockNumber,
      reason: "Blockchain receipt status is failed/reverted"
    };
  }

  const currentBlock = await provider.getBlockNumber();
  const confirmations = Math.max(0, currentBlock - receipt.blockNumber + 1);
  const required = getRequiredConfirmations(key);

  if (confirmations < required) {
    return {
      status: "pending",
      confirmations,
      amount: "0",
      blockNumber: receipt.blockNumber,
      reason: `Waiting for ${required} confirmations`
    };
  }

  const wallet = normalizeAddress(walletAddress);
  const expectedTo = expectedRecipient ? normalizeAddress(expectedRecipient) : null;
  const expected = expectedAmount != null ? String(expectedAmount) : null;


  // Native EVM coin verification.
  if (expectedAmount !== undefined && expectedAmount !== null && expectedAmount !== "" && !expectedTo) {
    throw new Error("Expected recipient is required for native EVM transaction verification");
  }

  // Caller selects native verification by passing expectedRecipient and the route's
  // asset is checked by the outer verifier. This helper supports both native and token.
  return {
    receipt,
    tx,
    confirmations,
    currentBlock,
    required,
    wallet,
    expectedTo,
    expected
  };
}

function parseEvmUsdtTransfers(receipt, tokenContract) {
  const transfers = [];
  const expectedContract = normalizeAddress(tokenContract);

  for (const log of receipt.logs || []) {
    if (normalizeAddress(log.address) !== expectedContract) continue;

    try {
      const parsed = ERC20_TRANSFER_IFACE.parseLog({
        topics: log.topics,
        data: log.data
      });

      if (!parsed || parsed.name !== "Transfer") continue;

      transfers.push({
        from: normalizeAddress(parsed.args.from),
        to: normalizeAddress(parsed.args.to),
        value: parsed.args.value
      });
    } catch {
      // Ignore unrelated logs from the same transaction.
    }
  }

  return transfers;
}

async function verifyEvmAssetTransaction({
  networkKey,
  asset,
  txHash,
  walletAddress,
  direction,
  expectedAmount,
  expectedRecipient
}) {
  const key = String(networkKey).toUpperCase();
  const normalizedAsset = String(asset).toUpperCase();
  const base = await verifyEvmTransaction({
    networkKey: key,
    txHash,
    walletAddress,
    direction,
    expectedAmount,
    expectedRecipient
  });

  if (base.status !== undefined && !base.receipt) return base;

  const { receipt, tx, confirmations, required, blockNumber } = base;
  const wallet = normalizeAddress(walletAddress);
  const recipient = normalizeAddress(expectedRecipient || "");

  if (normalizedAsset === "ETH") {
    const txFrom = normalizeAddress(tx.from);
    const txTo = normalizeAddress(tx.to);
    const value = BigInt(tx.value.toString());
    const expected = ethers.parseEther(String(expectedAmount));

    if (direction === "in") {
      if (txTo !== wallet) throw new Error("Transaction recipient does not match the registered wallet");
    } else {
      if (txFrom !== wallet) throw new Error("Transaction sender does not match the registered wallet");
      if (recipient && txTo !== recipient) throw new Error("Transaction recipient does not match the requested recipient");
    }

    if (value < expected) throw new Error("Verified on-chain amount is smaller than the requested amount");

    return {
      status: "verified",
      confirmations,
      amount: ethers.formatEther(value),
      blockNumber,
      reason: `Verified on-chain ${key} native transaction (${required} confirmations required)`
    };
  }

  if (normalizedAsset === "USDT") {
    const token = await verifyEvmUsdtContract(key);
    const transfers = parseEvmUsdtTransfers(receipt, token.address);
    const expectedUnits = ethers.parseUnits(String(expectedAmount), token.decimals);

    const matching = transfers.filter((t) => {
      if (direction === "in") {
        return t.to === wallet && (!tx.from || t.from === normalizeAddress(tx.from));
      }
      return t.from === wallet && (!recipient || t.to === recipient);
    });

    if (!matching.length) {
      throw new Error("No matching verified USDT Transfer event was found");
    }

    const total = matching.reduce((sum, t) => sum + BigInt(t.value.toString()), 0n);

    if (total < expectedUnits) {
      throw new Error("Verified on-chain USDT amount is smaller than the requested amount");
    }

    return {
      status: "verified",
      confirmations,
      amount: ethers.formatUnits(total, token.decimals),
      blockNumber,
      tokenContract: token.address,
      reason: "Verified against the allow-listed USDT contract and ERC-20 Transfer event"
    };
  }

  throw new Error("Unsupported EVM asset");
}

function tronHexToBase58(value) {
  try {
    return tronWeb.address.fromHex(value);
  } catch {
    return "";
  }
}

function decodeTronTransferLogs(info, tokenContract, walletAddress, direction, txOwner, expectedRecipient) {
  const transfers = [];
  const expectedContract = String(tokenContract).toLowerCase();
  const wallet = String(walletAddress).toLowerCase();
  const recipient = String(expectedRecipient || "").toLowerCase();
  const transferTopic = ethers.id("Transfer(address,address,uint256)").slice(2).toLowerCase();

  for (const log of info.log || []) {
    const logAddress = tronHexToBase58(log.address || "");
    if (!logAddress || logAddress.toLowerCase() !== expectedContract) continue;

    const topics = log.topics || [];
    if (!topics[0] || topics[0].toLowerCase().replace(/^0x/, "") !== transferTopic) continue;
    if (topics.length < 3) continue;

    const fromHex = "41" + topics[1].replace(/^0x/, "").slice(-40);
    const toHex = "41" + topics[2].replace(/^0x/, "").slice(-40);
    const from = tronHexToBase58(fromHex);
    const to = tronHexToBase58(toHex);

    let value = 0n;
    try {
      value = BigInt("0x" + String(log.data || "0").replace(/^0x/, ""));
    } catch {
      continue;
    }

    if (direction === "in" && to.toLowerCase() === wallet) {
      // The transaction owner is not necessarily the token sender for transferFrom,
      // so do not require txOwner == from here.
      transfers.push({ from, to, value });
    }

    if (direction === "out" && from.toLowerCase() === wallet &&
        (!recipient || to.toLowerCase() === recipient)) {
      transfers.push({ from, to, value });
    }
  }

  return transfers;
}

async function verifyTronAssetTransaction({
  asset,
  txHash,
  walletAddress,
  direction,
  expectedAmount,
  expectedRecipient
}) {
  if (!isValidTronAddress(walletAddress)) throw new Error("Invalid TRON wallet address");
  if (!/^[a-fA-F0-9]{64}$/.test(String(txHash))) throw new Error("Invalid TRON transaction hash");

  const tx = await tronWeb.trx.getTransaction(txHash);
  if (!tx || !tx.txID) throw new Error("TRON transaction not found");

  const info = await tronWeb.trx.getTransactionInfo(txHash);
  if (!info || !info.id) {
    return {
      status: "pending",
      confirmations: 0,
      amount: "0",
      blockNumber: null,
      reason: "TRON transaction is not confirmed/mined yet"
    };
  }

  const receiptResult = String(info.receipt?.result || "SUCCESS").toUpperCase();
  if (receiptResult !== "SUCCESS") {
    return {
      status: "rejected",
      confirmations: 0,
      amount: "0",
      blockNumber: Number(info.blockNumber || 0),
      reason: `TRON receipt result: ${receiptResult}`
    };
  }

  const current = await tronWeb.trx.getCurrentBlock();
  const currentBlock = Number(current?.block_header?.raw_data?.number || 0);
  const blockNumber = Number(info.blockNumber || 0);
  const confirmations = blockNumber > 0 ? Math.max(0, currentBlock - blockNumber + 1) : 0;
  const required = getRequiredConfirmations("TRON");

  if (confirmations < required) {
    return {
      status: "pending",
      confirmations,
      amount: "0",
      blockNumber,
      reason: `Waiting for ${required} TRON confirmations`
    };
  }

  const wallet = walletAddress.toLowerCase();
  const recipient = String(expectedRecipient || "").toLowerCase();
  const normalizedAsset = String(asset).toUpperCase();

  if (normalizedAsset === "TRX") {
    const contract = tx.raw_data?.contract?.[0];
    const value = contract?.parameter?.value;

    if (!contract || contract.type !== "TransferContract" || !value) {
      throw new Error("Verified transaction is not a native TRX transfer");
    }

    const owner = tronHexToBase58(value.owner_address || "");
    const to = tronHexToBase58(value.to_address || "");
    const amountSun = BigInt(String(value.amount || "0"));
    const expectedSun = BigInt(Math.round(Number(expectedAmount) * 1e6));

    if (direction === "in" && to.toLowerCase() !== wallet) {
      throw new Error("TRX recipient does not match the registered wallet");
    }
    if (direction === "out" && owner.toLowerCase() !== wallet) {
      throw new Error("TRX sender does not match the registered wallet");
    }
    if (direction === "out" && recipient && to.toLowerCase() !== recipient) {
      throw new Error("TRX recipient does not match the requested recipient");
    }
    if (amountSun < expectedSun) throw new Error("Verified on-chain TRX amount is too small");

    return {
      status: "verified",
      confirmations,
      amount: (Number(amountSun) / 1e6).toFixed(6),
      blockNumber,
      reason: "Verified from the TRON chain transaction data"
    };
  }

  if (normalizedAsset === "USDT") {
    const contractAddress = TRON_USDT_CONTRACT;
    const contract = await tronWeb.contract().at(contractAddress);
    const [symbol, decimals] = await Promise.all([
      contract.symbol().call(),
      contract.decimals().call()
    ]);

    if (String(symbol).toUpperCase() !== "USDT" || Number(decimals) !== 6) {
      throw new Error("Configured TRON USDT contract metadata verification failed");
    }

    const transfers = decodeTronTransferLogs(
      info,
      contractAddress,
      walletAddress,
      direction,
      tx.raw_data?.contract?.[0]?.parameter?.value?.owner_address,
      expectedRecipient
    );

    if (!transfers.length) {
      throw new Error("No matching verified TRC20 USDT Transfer event was found");
    }

    const total = transfers.reduce((sum, t) => sum + t.value, 0n);
    const expectedUnits = BigInt(Math.round(Number(expectedAmount) * 1e6));

    if (total < expectedUnits) throw new Error("Verified on-chain USDT amount is too small");

    return {
      status: "verified",
      confirmations,
      amount: (Number(total) / 1e6).toFixed(6),
      blockNumber,
      tokenContract: contractAddress,
      reason: "Verified against the allow-listed TRON USDT contract and Transfer event"
    };
  }

  throw new Error("Unsupported TRON asset");
}

async function verifySolanaAssetTransaction({
  asset,
  txHash,
  walletAddress,
  direction,
  expectedAmount,
  expectedRecipient
}) {
  if (!isValidSolanaAddress(walletAddress)) throw new Error("Invalid Solana wallet address");
  const connection = getSolanaConnection();
  const status = await connection.getSignatureStatuses([txHash], { searchTransactionHistory: true });
  const signatureStatus = status.value?.[0];

  if (!signatureStatus) {
    return { status: "pending", confirmations: 0, amount: "0", blockNumber: null, reason: "Solana signature not found" };
  }

  if (signatureStatus.err) {
    return { status: "rejected", confirmations: 0, amount: "0", blockNumber: null, reason: "Solana transaction failed" };
  }

  const tx = await connection.getParsedTransaction(txHash, {
    commitment: "confirmed",
    maxSupportedTransactionVersion: 0
  });

  if (!tx || tx.meta?.err) {
    return { status: "pending", confirmations: 0, amount: "0", blockNumber: tx?.slot || null, reason: "Solana transaction details are not yet available" };
  }

  const wallet = walletAddress;
  const recipient = expectedRecipient || "";
  const normalizedAsset = String(asset).toUpperCase();
  let amount = 0;

  if (normalizedAsset === "SOL") {
    const instructions = [
      ...(tx.transaction.message.instructions || []),
      ...((tx.meta.innerInstructions || []).flatMap((x) => x.instructions || []))
    ];

    for (const ix of instructions) {
      const parsed = ix?.parsed;
      if (!parsed || parsed.type !== "transfer" || parsed.info?.lamports == null) continue;
      const info = parsed.info;
      if (direction === "in" && info.destination === wallet) {
        amount += Number(info.lamports) / 1e9;
      }
      if (direction === "out" && info.source === wallet && (!recipient || info.destination === recipient)) {
        amount += Number(info.lamports) / 1e9;
      }
    }
  } else if (normalizedAsset === "USDT") {
    const pre = tx.meta.preTokenBalances || [];
    const post = tx.meta.postTokenBalances || [];
    const byIndex = new Map();

    for (const b of pre) {
      if (b.mint !== SOLANA_USDT_MINT || b.owner !== wallet) continue;
      if (!byIndex.has(b.accountIndex)) byIndex.set(b.accountIndex, { pre: 0, post: 0 });
      byIndex.get(b.accountIndex).pre = Number(b.uiTokenAmount?.uiAmountString || 0);
    }

    for (const b of post) {
      if (b.mint !== SOLANA_USDT_MINT || b.owner !== wallet) continue;
      if (!byIndex.has(b.accountIndex)) byIndex.set(b.accountIndex, { pre: 0, post: 0 });
      byIndex.get(b.accountIndex).post = Number(b.uiTokenAmount?.uiAmountString || 0);
    }

    for (const row of byIndex.values()) {
      const delta = row.post - row.pre;
      if (direction === "in" && delta > 0) amount += delta;
      if (direction === "out" && delta < 0) amount += Math.abs(delta);
    }
  } else {
    throw new Error("Unsupported Solana asset");
  }

  if (amount < Number(expectedAmount)) {
    throw new Error("Verified Solana amount is smaller than the requested amount");
  }

  return {
    status: "verified",
    confirmations: 1,
    amount: String(amount),
    blockNumber: tx.slot || null,
    tokenContract: normalizedAsset === "USDT" ? SOLANA_USDT_MINT : "",
    reason: "Verified from Solana parsed transaction state"
  };
}

async function verifyBitcoinTransaction({
  asset,
  txHash,
  walletAddress,
  direction,
  expectedAmount,
  expectedRecipient
}) {
  if (String(asset).toUpperCase() !== "BTC") throw new Error("Unsupported Bitcoin asset");
  if (!/^[a-fA-F0-9]{64}$/.test(String(txHash))) throw new Error("Invalid Bitcoin transaction ID");
  if (!isValidBitcoinAddress(walletAddress)) throw new Error("Invalid Bitcoin wallet address");

  const txResponse = await fetch(`${BITCOIN_API}/tx/${txHash}`);
  if (!txResponse.ok) {
    if (txResponse.status === 404) throw new Error("Bitcoin transaction not found");
    throw new Error(`Bitcoin API HTTP ${txResponse.status}`);
  }

  const tx = await txResponse.json();
  const status = tx.status || {};

  if (!status.confirmed) {
    return { status: "pending", confirmations: 0, amount: "0", blockNumber: null, reason: "Bitcoin transaction is not confirmed" };
  }

  const tipResponse = await fetch(`${BITCOIN_API}/blocks/tip/height`);
  if (!tipResponse.ok) throw new Error("Unable to read Bitcoin chain tip");
  const tip = Number(await tipResponse.text());
  const blockNumber = Number(status.block_height);
  const confirmations = Math.max(0, tip - blockNumber + 1);
  const required = getRequiredConfirmations("BITCOIN");

  if (confirmations < required) {
    return { status: "pending", confirmations, amount: "0", blockNumber, reason: `Waiting for ${required} Bitcoin confirmations` };
  }

  let amountSats = 0;

  if (direction === "in") {
    for (const vout of tx.vout || []) {
      if (vout.scriptpubkey_address === walletAddress) amountSats += Number(vout.value || 0);
    }
  } else {
    for (const vin of tx.vin || []) {
      if (vin.prevout?.scriptpubkey_address === walletAddress) amountSats += Number(vin.prevout.value || 0);
    }

    if (expectedRecipient) {
      const hasRecipient = (tx.vout || []).some(
        (vout) => vout.scriptpubkey_address === expectedRecipient
      );
      if (!hasRecipient) throw new Error("Bitcoin transaction does not pay the requested recipient");
    }
  }

  const amount = amountSats / 1e8;
  if (amount < Number(expectedAmount)) throw new Error("Verified Bitcoin amount is smaller than the requested amount");

  return {
    status: "verified",
    confirmations,
    amount: amount.toFixed(8),
    blockNumber,
    txFrom: direction === "out" ? walletAddress : "",
    recipientAddress: direction === "out" ? (expectedRecipient || "") : walletAddress,
    reason: "Verified from the Bitcoin blockchain transaction and UTXO data"
  };
}

async function verifyOnChainTransaction({
  user,
  chain,
  asset,
  txHash,
  direction,
  expectedAmount,
  expectedRecipient
}) {
  const normalizedChain = String(chain || "").toUpperCase();
  const normalizedAsset = String(asset || "").toUpperCase();
  const normalizedDirection = String(direction || "in").toLowerCase();

  if (!["in", "out"].includes(normalizedDirection)) {
    throw new Error("Direction must be 'in' or 'out'");
  }
  if (!isValidAmount(expectedAmount)) throw new Error("A positive expected amount is required");

  const walletAddress = getUserAddressForChain(user, normalizedChain);
  if (!walletAddress) throw new Error("No registered wallet address for this network");

  if (normalizedDirection === "out" && !expectedRecipient) {
    throw new Error("Recipient is required for outgoing verification");
  }

  let result;

  if (["ETH", "OPTIMISM", "ARBITRUM", "BASE"].includes(normalizedChain)) {
    if (!['ETH', 'USDT'].includes(normalizedAsset)) throw new Error("Unsupported EVM asset");
    result = await verifyEvmAssetTransaction({
      networkKey: normalizedChain,
      asset: normalizedAsset,
      txHash,
      walletAddress,
      direction: normalizedDirection,
      expectedAmount,
      expectedRecipient
    });
  } else if (normalizedChain === "TRON") {
    result = await verifyTronAssetTransaction({
      asset: normalizedAsset,
      txHash,
      walletAddress,
      direction: normalizedDirection,
      expectedAmount,
      expectedRecipient
    });
  } else if (normalizedChain === "SOLANA") {
    result = await verifySolanaAssetTransaction({
      asset: normalizedAsset,
      txHash,
      walletAddress,
      direction: normalizedDirection,
      expectedAmount,
      expectedRecipient
    });
  } else if (normalizedChain === "BITCOIN") {
    result = await verifyBitcoinTransaction({
      asset: normalizedAsset,
      txHash,
      walletAddress,
      direction: normalizedDirection,
      expectedAmount,
      expectedRecipient
    });
  } else {
    throw new Error("Unsupported blockchain network");
  }

  // Minimum USD rule is applied to the VERIFIED on-chain amount, not the
  // client-supplied amount. A below-minimum receive is never credited.
  if (result.status === "verified") {
    const usd = await getUsdValue(result.amount, normalizedAsset);
    // Incoming self-custody deposits have no maximum. Only the minimum
    // receive threshold is enforced after on-chain verification.
    if (usd.usdValue < MIN_TRANSACTION_USD) {
      result.status = "rejected";
      result.reason = `Verified amount is below the $${MIN_TRANSACTION_USD.toFixed(2)} USD minimum`;
    }
  }

  return {
    ...result,
    chain: normalizedChain,
    asset: normalizedAsset,
    direction: normalizedDirection,
    walletAddress,
    expectedAmount: String(expectedAmount),
    expectedRecipient: expectedRecipient || ""
  };
}

/* =========================================================
   USER / WALLET
========================================================= */

/*
 * IMPORTANT:
 * Wallets are created on the user's device.
 * This function ONLY creates the database record.
 */
async function registerUserWallet(telegramId, addresses) {
  const normalized = {
    tron: String(addresses.tron || "").trim(),
    evm: String(addresses.evm || "").trim(),
    solana: String(addresses.solana || "").trim(),
    bitcoin: String(addresses.bitcoin || "").trim()
  };

  if (!isValidTronAddress(normalized.tron)) {
    throw new Error("Invalid TRON wallet address");
  }

  if (!isValidEvmAddress(normalized.evm)) {
    throw new Error("Invalid EVM wallet address");
  }

  if (!isValidSolanaAddress(normalized.solana)) {
    throw new Error("Invalid Solana wallet address");
  }

  if (!isValidBitcoinAddress(normalized.bitcoin)) {
    throw new Error("Invalid Bitcoin wallet address");
  }

  const user = await User.findOneAndUpdate(
    {
      telegramId: String(telegramId)
    },
    {
      $set: {
        addresses: normalized,
        updatedAt: new Date()
      },
      $setOnInsert: {
        telegramId: String(telegramId),
        createdAt: new Date()
      }
    },
    {
      new: true,
      upsert: true,
      setDefaultsOnInsert: true
    }
  );

  return user;
}

/* =========================================================
   WALLET API
========================================================= */

/*
 * Register PUBLIC addresses created by the frontend.
 *
 * The request must NEVER contain:
 * privateKey
 * seedPhrase
 * mnemonic
 * secret
 */
app.post(
  "/api/wallet/register",
  async (req, res) => {
    try {
      const {
        telegramId,
        initData,
        addresses
      } = req.body;

      if (!telegramId) {
        return res.status(400).json({
          success: false,
          error: "Telegram ID required"
        });
      }

      if (
        !authenticateTelegramRequest(
          telegramId,
          initData
        )
      ) {
        return res.status(401).json({
          success: false,
          error: "Unauthorized request"
        });
      }

      if (!addresses || typeof addresses !== "object") {
        return res.status(400).json({
          success: false,
          error: "Public wallet addresses required"
        });
      }

      const forbiddenKeys = [
        "privateKey",
        "private_key",
        "seed",
        "seedPhrase",
        "seed_phrase",
        "mnemonic",
        "secret"
      ];

      for (const key of forbiddenKeys) {
        if (Object.prototype.hasOwnProperty.call(addresses, key)) {
          return res.status(400).json({
            success: false,
            error:
              "Private keys and seed phrases must never be sent to the server"
          });
        }
      }

      const user =
        await registerUserWallet(
          telegramId,
          addresses
        );

      return res.json({
        success: true,
        message:
          "Public wallet addresses registered",
        addresses: {
          TRX: user.addresses.tron,
          USDT_TRON: user.addresses.tron,

          ETH: user.addresses.evm,
          USDT_ETH: user.addresses.evm,
          OPTIMISM: user.addresses.evm,
          ARBITRUM: user.addresses.evm,
          BASE: user.addresses.evm,

          SOL: user.addresses.solana,
          BTC: user.addresses.bitcoin
        }
      });
    } catch (error) {
      console.error(
        "Wallet registration error:",
        error.message
      );

      return res.status(400).json({
        success: false,
        error:
          error.message ||
          "Wallet registration failed"
      });
    }
  }
);

app.post(
  "/api/wallet",
  async (req, res) => {
    try {
      const {
        telegramId,
        initData
      } = req.body;

      if (!telegramId) {
        return res.status(400).json({
          success: false,
          error: "Telegram ID required"
        });
      }

      if (
        !authenticateTelegramRequest(
          telegramId,
          initData
        )
      ) {
        return res.status(401).json({
          success: false,
          error: "Unauthorized request"
        });
      }

      const user =
        await User.findOne({
          telegramId: String(telegramId)
        });

      /*
       * Do NOT generate a wallet here.
       * If no wallet exists, the frontend must create one locally.
       */
      if (!user) {
        return res.status(404).json({
          success: false,
          walletSetupRequired: true,
          error:
            "Wallet not registered. Create the wallet on the user's device and call /api/wallet/register."
        });
      }

      const tronBalances =
        await getTronBalances(
          user.addresses.tron
        );

      const evmBalances = {};
      const usdtBalances = {};

      for (
        const networkKey of Object.keys(EVM_NETWORKS)
      ) {
        try {
          evmBalances[networkKey] =
            await getEvmNativeBalance(
              networkKey,
              user.addresses.evm
            );
        } catch (error) {
          evmBalances[networkKey] = 0;
        }

        try {
          usdtBalances[networkKey] =
            await getEvmUsdtBalance(
              networkKey,
              user.addresses.evm
            );
        } catch (error) {
          usdtBalances[networkKey] = 0;
        }
      }

      let sol = 0;

      try {
        if (user.addresses.solana) {
          const lamports =
            await getSolanaConnection()
              .getBalance(
                new PublicKey(
                  user.addresses.solana
                )
              );

          sol = lamports / 1e9;
        }
      } catch (error) {
        console.error(
          "SOL balance error:",
          error.message
        );
      }

      const btc =
        await getBitcoinBalance(
          user.addresses.bitcoin
        );

      return res.json({
        success: true,

        addresses: {
          TRX: user.addresses.tron,
          USDT_TRON: user.addresses.tron,

          ETH: user.addresses.evm,
          USDT_ETH: user.addresses.evm,
          OPTIMISM: user.addresses.evm,
          ARBITRUM: user.addresses.evm,
          BASE: user.addresses.evm,

          SOL: user.addresses.solana,
          BTC: user.addresses.bitcoin
        },

        verifiedBalances: {
          trx: Number(
            tronBalances.trx.toFixed(6)
          ),

          usdt_tron: Number(
            tronBalances.usdt.toFixed(6)
          ),

          eth: Number(
            (evmBalances.ETH || 0).toFixed(8)
          ),

          usdt_eth: Number(
            (usdtBalances.ETH || 0).toFixed(6)
          ),

          optimism: Number(
            (evmBalances.OPTIMISM || 0).toFixed(8)
          ),

          arbitrum: Number(
            (evmBalances.ARBITRUM || 0).toFixed(8)
          ),

          base: Number(
            (evmBalances.BASE || 0).toFixed(8)
          ),

          btc: Number(
            btc.toFixed(8)
          ),

          sol: Number(
            sol.toFixed(9)
          )
        },

        limits: {
          minimumTransactionUsd: MIN_TRANSACTION_USD,
          maximumTransactionUsd: MAX_TRANSACTION_USD,
          receiveMaximumTransactionUsd: null,
          description: "Send: $0.10 minimum, unlimited maximum; incoming receive: $0.10 minimum, no maximum"
        },

        networkFee: {
          sendPercent:
            PLATFORM_FEE_PERCENT,

          swipePercent:
            SWIPE_SWAP_FEE_PERCENT,

          swapPercent:
            SWIPE_SWAP_FEE_PERCENT,

          addresses:
            FEE_ADDRESSES
        }
      });
    } catch (error) {
      console.error(
        "Wallet API error:",
        error
      );

      return res.status(500).json({
        success: false,
        error:
          "On-chain balance query failed"
      });
    }
  }
);

/* =========================================================
   SEND PREPARATION
========================================================= */

/*
 * This endpoint NEVER signs or broadcasts.
 * It returns a safe transaction plan for the frontend.
 */
app.post(
  "/api/send/prepare",
  async (req, res) => {
    try {
      const {
        telegramId,
        initData,
        sessionId,
        toAddress,
        amount,
        chain,
        asset
      } = req.body;

      if (!telegramId) {
        return res.status(400).json({
          success: false,
          error: "Telegram ID required"
        });
      }

      try { await requireSecureSession({ telegramId, initData, sessionId, req, sensitive:true }); }
      catch (sessionError) {
        if (sessionError.code === "DEVICE_VERIFICATION_REQUIRED") return res.status(403).json({success:false,code:sessionError.code,error:sessionError.message});
        throw sessionError;
      }

      if (!toAddress) {
        return res.status(400).json({
          success: false,
          error:
            "Recipient address required"
        });
      }

      if (!isValidAmount(amount)) {
        return res.status(400).json({
          success: false,
          error: "Invalid amount"
        });
      }

      const normalizedChain =
        String(chain || "").toUpperCase();

      const normalizedAsset =
        String(asset || "").toUpperCase();

      const { price: usdPrice, usdValue: grossUsdValue } =
        await getUsdValue(amount, normalizedAsset);

      enforceUsdTransactionLimits(grossUsdValue, "send");

      const { gross, fee, receive } =
        calculateFee(amount);

      const receiveUsdValue =
        receive * usdPrice;

      if (receiveUsdValue < MIN_TRANSACTION_USD) {
        throw new Error(
          `Minimum receive amount after the 0.5% network fee is $${MIN_TRANSACTION_USD.toFixed(2)} USD equivalent. Please send a slightly larger amount.`
        );
      }

      // Incoming deposits and outgoing Send are unlimited at the application layer.
      // External blockchain/provider/network limits can still apply.


      if (receive <= 0) {
        throw new Error(
          "Amount is too small after fee"
        );
      }

      let tokenContract = null;
      let tokenDecimals = null;

      /* ---------------- EVM ---------------- */

      if (
        ["ETH", "USDT"].includes(normalizedAsset) &&
        EVM_NETWORKS[normalizedChain]
      ) {
        if (!isValidEvmAddress(toAddress)) {
          throw new Error(
            "Invalid EVM recipient address"
          );
        }

        if (normalizedAsset === "USDT") {
          tokenContract =
            EVM_NETWORKS[normalizedChain].usdt;

          if (!tokenContract) {
            throw new Error(
              `USDT contract is not configured for ${normalizedChain}`
            );
          }

          tokenDecimals = 6;
        }
      }

      /* ---------------- TRON ---------------- */

      else if (
        normalizedChain === "TRON" &&
        ["TRX", "USDT"].includes(normalizedAsset)
      ) {
        if (!isValidTronAddress(toAddress)) {
          throw new Error(
            "Invalid TRON recipient address"
          );
        }

        if (normalizedAsset === "USDT") {
          tokenContract = TRON_USDT_CONTRACT;
          tokenDecimals = 6;
        }
      }

      /* ---------------- SOLANA ---------------- */

      else if (
        normalizedChain === "SOLANA" &&
        normalizedAsset === "SOL"
      ) {
        if (!isValidSolanaAddress(toAddress)) {
          throw new Error(
            "Invalid Solana recipient address"
          );
        }
      }

      /* ---------------- BITCOIN ---------------- */

      else if (
        normalizedChain === "BITCOIN" &&
        normalizedAsset === "BTC"
      ) {
        if (!isValidBitcoinAddress(toAddress)) {
          throw new Error(
            "Invalid Bitcoin recipient address"
          );
        }
      }

      else {
        throw new Error(
          "Unsupported chain / asset combination"
        );
      }

      const feeAddress =
        getFeeAddress(
          normalizedChain,
          normalizedAsset
        );

      if (!feeAddress) {
        throw new Error(
          "Platform fee address is not configured for this network"
        );
      }

      /*
       * Failure-safe non-custodial fee model:
       * 1. User signs/broadcasts ONLY the recipient transfer first.
       * 2. The backend independently verifies that transfer on-chain.
       * 3. Only after successful verification may the client request a fee plan.
       *
       * This prevents a platform-fee transaction from being charged when the
       * recipient transfer fails/reverts. The backend never receives a key.
       */
      return res.json({
        success: true,

        signingRequired: true,
        broadcastRequired: true,

        chain: normalizedChain,
        asset: normalizedAsset,

        recipient: toAddress,

        grossAmount: String(amount),

        minimumUsd: MIN_TRANSACTION_USD,
        usdPrice: usdPrice,
        grossUsdValue: Number(grossUsdValue.toFixed(4)),
        receiveUsdValue: Number(receiveUsdValue.toFixed(4)),

        networkFeePercent:
          PLATFORM_FEE_PERCENT,

        networkFee:
          fee.toFixed(8),

        receiveAmount:
          receive.toFixed(8),

        feePolicy:
          "A 0.5% network fee is charged in the same asset/network selected for the Send. The fee is payable only after the recipient transfer is independently verified on-chain. If the recipient transfer fails/reverts, no fee transfer should be broadcast. Blockchain gas/network charges remain separate and are paid according to the network.",

        feeRecipient:
          feeAddress,

        token: tokenContract
          ? {
              contract: tokenContract,
              decimals: tokenDecimals
            }
          : null,

        transactionModel: {
          recipientTransfer: {
            to: toAddress,
            amount: receive.toFixed(8),
            requiredFirst: true
          },

          networkFeeTransfer: {
            to: feeAddress,
            amount: fee.toFixed(8),
            requiredOnlyAfterRecipientVerification: true
          }
        },

        message:
          "Transaction plan prepared. Sign on the user's device. Never send private keys to this server."
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        error:
          error.message ||
          "Transaction preparation failed"
      });
    }
  }
);

/* =========================================================
   SEND FEE RELEASE (FAIL-SAFE)
========================================================= */

/*
 * A 0.5% network fee is never authorized merely because a send was prepared.
 * The recipient transfer must first be independently verified on-chain.
 * If the recipient transfer failed/reverted, this endpoint cannot release
 * a fee plan. This is the key failure-safety rule for outgoing network fees.
 */
app.post("/api/send/fee/prepare", async (req, res) => {
  try {
    const { telegramId, initData, sessionId, txHash, chain, asset, amount, expectedRecipient } = req.body;

    if (!telegramId || !txHash || !chain || !asset || !amount || !expectedRecipient) {
      return res.status(400).json({ success: false, error: "telegramId, txHash, chain, asset, amount and expectedRecipient are required" });
    }
    try { await requireSecureSession({telegramId,initData,sessionId,req,sensitive:true}); }
    catch(sessionError){ if(sessionError.code==="DEVICE_VERIFICATION_REQUIRED") return res.status(403).json({success:false,code:sessionError.code,error:sessionError.message}); throw sessionError; }

    const user = await User.findOne({ telegramId: String(telegramId) });
    if (!user) return res.status(404).json({ success: false, error: "Wallet not registered" });

    const verification = await verifyOnChainTransaction({
      user,
      chain: String(chain).toUpperCase(),
      asset: String(asset).toUpperCase(),
      txHash: String(txHash).trim(),
      direction: "out",
      expectedAmount: String(amount),
      expectedRecipient: String(expectedRecipient).trim()
    });

    if (verification.status !== "verified") {
      return res.status(409).json({
        success: false,
        feeReleased: false,
        status: verification.status,
        reason: verification.reason || "Recipient transfer is not verified"
      });
    }

    const { fee } = calculateFee(verification.amount);
    const feeAddress = getFeeAddress(String(chain).toUpperCase(), String(asset).toUpperCase());
    if (!feeAddress) throw new Error("Network fee address is not configured for this network");

    return res.json({
      success: true,
      feeReleased: true,
      recipientTransferVerified: true,
      chain: String(chain).toUpperCase(),
      asset: String(asset).toUpperCase(),
      txHash: String(txHash).trim(),
      verifiedAmount: String(verification.amount),
      networkFeePercent: PLATFORM_FEE_PERCENT,
      networkFee: fee.toFixed(8),
      platformFee: fee.toFixed(8),
      feeRecipient: feeAddress,
      message: "Recipient transfer verified on-chain. Only now may the wallet sign/broadcast the 0.5% network-fee transfer on the selected network/asset."
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      feeReleased: false,
      error: error.message || "Fee release verification failed"
    });
  }
});

/* =========================================================
   ON-CHAIN TRANSACTION VERIFICATION API
========================================================= */

/*
 * The frontend calls this after broadcasting a transaction, or when a
 * deposit is detected. The server independently queries the blockchain.
 * It NEVER trusts a client-provided balance, token contract or tx status.
 * A successful response means the transaction itself was verified; it does
 * NOT mint or increment an internal balance.
 */
app.post(
  "/api/transaction/verify",
  async (req, res) => {
    try {
      const {
        telegramId,
        initData,
        sessionId,
        txHash,
        chain,
        asset,
        direction,
        expectedAmount,
        expectedRecipient
      } = req.body;

      if (!telegramId || !txHash || !chain || !asset || !direction || !expectedAmount) {
        return res.status(400).json({
          success: false,
          error: "telegramId, txHash, chain, asset, direction and expectedAmount are required"
        });
      }

      await getOrCreateSession({telegramId,sessionId,req});

      const user = await User.findOne({
        telegramId: String(telegramId)
      });

      if (!user) {
        return res.status(404).json({
          success: false,
          error: "Wallet not registered"
        });
      }

      const normalizedChain = String(chain).toUpperCase();
      const normalizedAsset = String(asset).toUpperCase();
      const normalizedDirection = String(direction).toLowerCase();

      // Never allow the client to choose an arbitrary token contract.
      // The verifier selects the contract from the server-side allow-list.
      if (normalizedAsset === "USDT") {
        if (["ETH", "OPTIMISM", "ARBITRUM", "BASE"].includes(normalizedChain)) {
          if (!EVM_NETWORKS[normalizedChain]?.usdt) {
            return res.status(400).json({
              success: false,
              error: `USDT is disabled on ${normalizedChain} because no allow-listed contract is configured`
            });
          }
        }
      }

      // Enforce both minimum and maximum eligibility against the requested amount.
      const verificationUsd = await getUsdValue(expectedAmount, normalizedAsset);
      enforceUsdTransactionLimits(
        verificationUsd.usdValue,
        normalizedDirection === "in" ? "receive" : "send"
      );

      const verification = await verifyOnChainTransaction({
        user,
        chain: normalizedChain,
        asset: normalizedAsset,
        txHash: String(txHash).trim(),
        direction: normalizedDirection,
        expectedAmount: String(expectedAmount),
        expectedRecipient: expectedRecipient ? String(expectedRecipient).trim() : ""
      });

      verification.usdValue = Number((await getUsdValue(verification.amount || expectedAmount, normalizedAsset)).usdValue || 0);
      verification.recipientAddress = normalizedDirection === "in" ? verification.walletAddress : (expectedRecipient || "");

      const doc = await TransactionVerification.findOneAndUpdate(
        {
          telegramId: String(telegramId),
          txHash: String(txHash).trim(),
          chain: normalizedChain,
          direction: normalizedDirection
        },
        {
          $set: {
            telegramId: String(telegramId),
            asset: normalizedAsset,
            status: verification.status,
            confirmations: verification.confirmations || 0,
            amount: String(verification.amount || "0"),
            address: verification.walletAddress,
            tokenContract: verification.tokenContract || "",
            blockNumber: verification.blockNumber ?? null,
            reason: verification.reason || "",
            senderAddress: verification.txFrom || (normalizedDirection === "out" ? (verification.senderAddress || "") : ""),
            recipientAddress: verification.recipientAddress || (normalizedDirection === "in" ? (verification.walletAddress || "") : (expectedRecipient || "")),
            usdValue: Number(verification.usdValue || 0),
            platformFee: normalizedDirection === "out" ? String(calculateFee(verification.amount || 0).fee.toFixed(8)) : "0",
            feeRecipient: normalizedDirection === "out" ? (getFeeAddress(normalizedChain, normalizedAsset) || "") : "",
            updatedAt: new Date()
          },
          $setOnInsert: {
            createdAt: new Date()
          }
        },
        {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true
        }
      );

      return res.status(verification.status === "rejected" ? 400 : 200).json({
        success: verification.status === "verified",
        verified: verification.status === "verified",
        status: verification.status,
        chain: normalizedChain,
        asset: normalizedAsset,
        direction: normalizedDirection,
        txHash: String(txHash).trim(),
        confirmations: verification.confirmations || 0,
        requiredConfirmations: getRequiredConfirmations(normalizedChain),
        amount: String(verification.amount || "0"),
        walletAddress: verification.walletAddress,
        tokenContract: verification.tokenContract || null,
        senderAddress: verification.txFrom || "",
        recipientAddress: verification.recipientAddress || (normalizedDirection === "in" ? verification.walletAddress : (expectedRecipient || "")),
        usdValue: Number(verification.usdValue || 0),
        blockNumber: verification.blockNumber ?? null,
        reason: verification.reason,
        minimumUsd: MIN_TRANSACTION_USD,
        ledgerRecordId: String(doc._id),
        balanceUpdate: false,
        message: verification.status === "verified"
          ? "Blockchain transaction verified. No dummy/internal balance was created or incremented."
          : "Transaction is not yet eligible for crediting."
      });
    } catch (error) {
      console.error("On-chain transaction verification error:", error.message);

      return res.status(400).json({
        success: false,
        verified: false,
        status: "rejected",
        error: error.message || "Blockchain transaction verification failed",
        balanceUpdate: false
      });
    }
  }
);

/* =========================================================
   SESSIONS / DEVICE SECURITY
========================================================= */
app.post("/api/session/register", async (req,res)=>{try{const {telegramId,initData,sessionId}=req.body;const session=await requireSecureSession({telegramId,initData,sessionId,req});return res.json({success:true,trusted:session.trusted,blocked:session.blocked,sensitiveVerified:Boolean(session.sensitiveVerifiedUntil&&session.sensitiveVerifiedUntil>new Date()),additionalVerificationRequired:!session.trusted});}catch(e){return res.status(400).json({success:false,error:e.message});}});
app.post("/api/session/approve", async (req,res)=>{try{const {telegramId,initData,sessionId}=req.body;if(!authenticateTelegramRequest(telegramId,initData))return res.status(401).json({success:false,error:"Unauthorized request"});const session=await getOrCreateSession({telegramId,sessionId,req});if(session.blocked)return res.status(403).json({success:false,error:"This session is blocked"});session.trusted=true;session.sensitiveVerifiedUntil=new Date(Date.now()+15*60*1000);await session.save();return res.json({success:true,trusted:true,sensitiveVerified:true,expiresAt:session.sensitiveVerifiedUntil});}catch(e){return res.status(400).json({success:false,error:e.message});}});
app.post("/api/session/list", async (req,res)=>{try{const {telegramId,initData,sessionId}=req.body;if(!authenticateTelegramRequest(telegramId,initData))return res.status(401).json({success:false,error:"Unauthorized request"});const current=await getOrCreateSession({telegramId,sessionId,req});const rows=await Session.find({telegramId:String(telegramId)}).sort({lastSeenAt:-1}).lean();return res.json({success:true,sessions:rows.map(x=>({id:String(x._id),device:x.deviceLabel,trusted:x.trusted,blocked:x.blocked,current:x.sessionIdHash===current.sessionIdHash,firstSeenAt:x.firstSeenAt,lastSeenAt:x.lastSeenAt,sensitiveVerifiedUntil:x.sensitiveVerifiedUntil}))});}catch(e){return res.status(400).json({success:false,error:e.message});}});
app.post("/api/session/revoke", async (req,res)=>{try{const {telegramId,initData,sessionId,targetSessionDbId}=req.body;if(!authenticateTelegramRequest(telegramId,initData))return res.status(401).json({success:false,error:"Unauthorized request"});const current=await getOrCreateSession({telegramId,sessionId,req});if(String(current._id)===String(targetSessionDbId))return res.status(400).json({success:false,error:"Current session cannot revoke itself"});const target=await Session.findOne({_id:targetSessionDbId,telegramId:String(telegramId)});if(!target)return res.status(404).json({success:false,error:"Session not found"});target.blocked=true;target.trusted=false;target.sensitiveVerifiedUntil=null;await target.save();return res.json({success:true,revoked:true});}catch(e){return res.status(400).json({success:false,error:e.message});}});

/* =========================================================
   TRANSACTION HISTORY
========================================================= */
app.post("/api/transactions/history", async (req,res)=>{try{const {telegramId,initData,sessionId,limit=50}=req.body;if(!authenticateTelegramRequest(telegramId,initData))return res.status(401).json({success:false,error:"Unauthorized request"});await getOrCreateSession({telegramId,sessionId,req});const docs=await TransactionVerification.find({telegramId:String(telegramId)}).sort({createdAt:-1}).limit(Math.min(100,Math.max(1,Number(limit)||50))).lean();return res.json({success:true,transactions:docs.map(d=>({id:String(d._id),txid:d.txHash,network:d.chain,asset:d.asset,direction:d.direction,status:d.status,confirmations:d.confirmations,requiredConfirmations:getRequiredConfirmations(d.chain),senderAddress:d.senderAddress||"",recipientAddress:d.recipientAddress||"",tokenContract:d.tokenContract||null,amount:d.amount,usdValue:d.usdValue||0,platformFee:d.platformFee||"0",feeRecipient:d.feeRecipient||"",blockNumber:d.blockNumber,reason:d.reason,createdAt:d.createdAt,updatedAt:d.updatedAt}))});}catch(e){return res.status(400).json({success:false,error:e.message});}});

/* =========================================================
   SWIPE / SWAP
========================================================= */

app.post(
  "/api/swipe-swap/prepare",
  async (req, res) => {
    try {
      const {
        telegramId,
        initData,
        sessionId
      } = req.body;

      try { await requireSecureSession({ telegramId, initData, sessionId, req, sensitive:true }); }
      catch (sessionError) { if (sessionError.code === "DEVICE_VERIFICATION_REQUIRED") return res.status(403).json({success:false,code:sessionError.code,error:sessionError.message}); throw sessionError; }

      return res.json({
        success: true,

        networkFeePercent:
          SWIPE_SWAP_FEE_PERCENT,

        platformFee: 0,

        networkFeeOnly: true,

        signingRequired: true,
        broadcastRequired: true,

        message:
          "Select a DEX/route on the client, build the transaction, and require the user to sign it locally. The backend does not hold keys."
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        error:
          error.message ||
          "Swap preparation failed"
      });
    }
  }
);

/* =========================================================
   HEALTH
========================================================= */

app.get("/", (req, res) => {
  res.json({
    success: true,
    service: "OPEN WALLET",
    status: "LIVE",
    version: "5.0.0",

    custodialPrivateKeys: false,
    privateKeysStored: false,
    fakeTxid: false,
    balanceSource: "BLOCKCHAIN_ONLY",
    transactionVerification: true,
    dummyBalanceUpdates: false,
    fakeTokenContractsAccepted: false,

    supportedAssets: [
      "ETH",
      "USDT",
      "TRX",
      "SOL",
      "BTC"
    ],

    supportedNetworks: [
      "Ethereum",
      "Optimism",
      "Arbitrum",
      "Base",
      "TRON",
      "Solana",
      "Bitcoin"
    ],

    platformFee:
      "0.5% on Send; 0% on Swipe/Swap",

    note:
      "Wallet creation and transaction signing are client-side."
  });
});

/* =========================================================
   404
========================================================= */

app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: "Route not found"
  });
});

/* =========================================================
   ERROR HANDLER
========================================================= */

app.use(
  (error, req, res, next) => {
    console.error(
      "Unhandled server error:",
      error
    );

    res.status(500).json({
      success: false,
      error: "Internal server error"
    });
  }
);

/* =========================================================
   START SERVER
========================================================= */

async function startServer() {
  try {
    if (!MONGO_URI) {
      throw new Error(
        "MONGO_URI is missing"
      );
    }

    if (!BOT_TOKEN) {
      throw new Error(
        "BOT_TOKEN is missing"
      );
    }

    await mongoose.connect(MONGO_URI);

    console.log(
      "MongoDB connected"
    );

    app.listen(
      PORT,
      "0.0.0.0",
      () => {
        console.log(
          `OPEN WALLET server running on port ${PORT}`
        );

        console.log(
          "Network fee: 0.5% of Send amount, charged in the selected asset/network"
        );

        console.log(
          `Minimum Send/Receive: $${MIN_TRANSACTION_USD.toFixed(2)} USD equivalent`
        );

        console.log(
          "Swipe/Swap fee: 0%"
        );

        console.log(
          "Private keys stored: NO"
        );

        console.log(
          "Wallet generation: CLIENT-SIDE"
        );
      }
    );
  } catch (error) {
    console.error(
      "Server startup failed:",
      error.message
    );

    process.exit(1);
  }
}

startServer();
